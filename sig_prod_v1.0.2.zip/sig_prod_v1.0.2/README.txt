Signature Product Code
----------------------

Authors: Shawn Martin, W. Michael Brown, Carla Churchwell

Contact:

Shawn Martin
Computational Biology
Sandia National Laboratories
PO Box 5800, MS 0310
Albuquerque, NM 87185

smartin@sandia.gov


Installation
------------

These codes have been compiled with cygwin gcc and g++.
Other compilers have not been tested.

1. Download svm light V5.0 from T. Joachims website at
   http://svmlight.joachims.org/.  Put the file
   "svm_light.tar.gz" into the svm_light_patch directory.

2. Unzip svm light V5 in the svm_light patch directory
   by typing: tar -xvzf svm_light.tar.gz

3. Apply the signature product patch in the svm_light_patch
   directory by typing: patch < svmpatch

4. Compile the executables by typing "make" in this directory.

Examples
--------

Please go to the example folder for documentation on how
to run the signature product codes.


Citation
--------

For details on the algorithm underlying this code see:

S. Martin, D. Roe, and J.-L. Faulon (2005), "Predicting Protein-Protein
Interactions using Signature Products", Bioinformatics 21(2):218-226.

See also LICENSE.txt for more information about using the code.