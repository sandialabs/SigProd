H. pylori example
-----------------

This is an example of the product signature code applied to H. pylori.
The H. pylori data was obtained from the supplementary data associated
with

J. C. Rain et al., "The protein-protein interaction map of Helicobacter
pylori", Nature, 2001, 409(6817):211-215.

There were 1570 unique proteins in this set of interactions whose
sequences were available from Swiss-prot.  These sequences are
contained in the file HELICO_seq.txt.

There were 1458 interactions satisfying these criterion.  We provided
an addition 1458 non-interactions (selected at random) to produce
a dataset of 2917 protein pairs.  These pairs are contained in
HELICO_pairs.txt.

Hence we have the following files, with the following formats:

  1. HELICO_seq.txt which contains amino acid sequences of 1570
     H. pylori proteins.  The format of this file is one sequence
     per line.
  2. HELICO_pairs.txt which contains pairs of proteins specified
     by indices into the previous file.  The format of this file
     is line 1: number of pairs in this file.  Remaining lines:
     pairs of integers separated by a tab, where each integer is
     an index into the sequence file (or the kernel matrix
     produces by kernel_mat).  Note that the indices start at 0.
  3. train.dat and test.dat.  These two files are required by
     svm_light. Each line in these files has the format:
     <-1|1><space><1:x>, where the first entry <-1|1> gives the
     class labels (binding or not binding) and the x gives the
     protein pair (as an index into the pairs file HELICO_pairs.txt).
     Note again that indices start at 0.

To see how signature product performs on the H. pylori dataset, we can
execute the following commands (from this directory):

  1. Create the kernel matrix for use by svm_learn using
     kernel_mat.  This can be accomplished with the command
     "../bin/kernel_mat HELICO_seq.txt HELICO_kmat.txt".
  2. Train an SVM using svm_light with the command
     "../bin/svm_learn HELICO_kmat.txt HELICO_pairs.txt
      train.dat model.dat".
  3. Test the SVM using the command:
     "../bin/svm_classify HELICO_kmat.txt HELICO_pairs.txt test.dat
      model.dat results.dat".
  4. The accuracy is reported as 82.2% for this train/test combination.

Proteome-Wide Predictions
-------------------------

Signature product can be used to extrapolate from a single experiment
to an entire proteome.  Here we show how to do this using the program
make_preds.

  1. If the files HELICO_kmat.txt has not yet been created then
     create the kernel matrix now by typing "../bin/kernel_mat
     HELICO_seq.txt HELICO_kmat.txt".
  2. Train an SVM on the entire H. pylori dataset by typing
     "../bin/svm_learn HELICO_kmat.txt HELICO_pairs.txt all.dat
     full_model.dat".
  3. Make the proteome wide predictions by typing "../bin/make_preds
     HELICO_kmat.txt HELICO_pairs.txt full_model.dat HELICO_preds.txt".

H. pylori to E. Coli
--------------------

The make_preds program can also be used to extrapolate from one
organism to another.  

  1. We now use the kernel_mat program to produce a kernel
     matrix going from H. pylori to E. coli.  This is accomplished
     by typing "../bin/kernel_mat HELICO_seq.txt ECOLI_seq.txt
     HE_kmat.txt".  ECOLI_seq.txt was obtained from the DIP
     database.
  2. Use the model.dat file created by training the SVM on the full
     H. pylori set to make the predictions by typing
     "../bin/make_preds HE_kmat.txt HELICO_pairs.txt full_model.dat
     ECOLI_preds.txt".  To create the full_model.dat file type
     "../bin/svm_learn HELICO_kmat.txt HELICO_pairs.txt all.dat
     full_model.dat".

Notes & Other Documentation
---------------------------

  1. Each program in this suite of codes has documentation available
     by typing the name of the program with no arguments.
  2. kernel_mat can produce output in any combination of
     sparse and symmetric matrices.  These matrices can be read
     by all the other program.  To produce sparse output, use the "-s"
     flag.  To produce symmetric output, use only one input filename.
  3. As reported in our paper, the make_preds program does not
     typically produce reliable predictions when extrapolating
     from one organism to another.

Bug Reports
-----------

Please send bug reports to

S. Martin
smartin@sandia.gov

9/22/04
