/***************************************************************************
                                commandline.h
                               W. Michael Brown
                             -------------------

  Command line parsing stuff..
                             
    begin                : Sun Jun 11 2003
    copyright            : (C) 2003 by W. Michael Brown
    email                : mbrown@nirvana.unm.edu
 ***************************************************************************/

#ifndef COMMANDLINE_H
#define COMMANDLINE_H

#include "error.h"
#include "misc.h"
#include <map>
#include <vector>
#include <string>
#include <stdlib.h>
#include <iostream>
using namespace std;
   
// This class is for internal use within CommandLine
class Parameter {
 public:
  friend class CommandLine;
  Parameter();
  ~Parameter();
  
 private:
  unsigned num_args;       // Maximum number of arguments for the parameter
  unsigned manditory_args; // Minimum number of arguments for the parameter
  bool manditory;			     // This parameter MUST be set

  bool dash;  				     // Allow for signed numbers (dashes in args)

  bool set;                // This parameter has been set
  vector<char *> args;

  // Strings for man page description
  vector<string> argnames; // Names for each argument to the parameter
  vector<string> description; // Description for how to set this parameter
};

/// Parsing of command-line parameters and automatic man page generation
/** Currently undocumented */
class CommandLine {
 public:
  CommandLine();
  ~CommandLine();

  // Add allowed arguments
  void add(char n, unsigned num);
  void addmanditory(char n, unsigned num);
  // Allow dashes to be in the arguments (for inputting negative nums)
  void addsigned(char n, unsigned num);

 	// Require different minimum and maximum number of args
	void add(char n, unsigned num, unsigned man_num);
  void addmanditory(char n, unsigned num, unsigned man_num);
  void addsigned(char n, unsigned num, unsigned man_num);

  // Add a help argument (does not require other manditory arguments be set)
  void addhelp(char n, unsigned num);
  
  // Add descriptions for man pages
  void addargname(char n, string an);
  void addargnames(char n, unsigned num, const string args[]);
  void adddescription(char n, string d);
  void adddescription(char n, unsigned num, const string d[]);

  void addtoman_chapter(string name,string body);
  void addtoman_chapter(string name,unsigned line_count,const string body[]);
  
  // Returns the number of arguments that are not parameters (' ' name)
  unsigned argsize();
  // Returns the argument size for a parameter
  unsigned argsize(char n);
  // Whether or not this parameter was set
  bool set(char n);
  bool operator [](char n);

  char *arg(char n, unsigned num);         // Return arg as string
  int argint(char n, unsigned num);        // Return arg as integer
  double argdouble(char n, unsigned num);  // Return arg as double
  string argstring(char n, unsigned num);  // Return arg as string

  // Parse the command line arguments
  bool parse(int argc, char* argv[], Error *error);
  
  string program_name();
  // Write out a man_page
  // NAME, VERSION, SYNOPSIS, DESCRIPTION, PARAMETERS, added sections
  // Suggested order for added: USAGE, EXAMPLES, AUTHORS, BUGS, SEE ALSO
	ostream & write_man_page(ostream & out, string version, string header);
        
  // Advanced stuff
  ostream & writeman_chapter(ostream &out, string name, string bold,
														 string italic, string regular);

  // Return a string with all of the options in a man page synopsis format
  string format_synopsis(string bold, string italic, string regular);
  // Format a parameter as a string with argument names
  // Parameter is bold, arguments are italics, optional args are bracketed
  string format_parameter(char param, string bold, string italic,
													string regular);
  // Formats the strings in input for a man page by replacing newlines and
  // adding bold and italic fonts to parameters and arguments respectively
	vector<string> man_format(const vector<string> &input, string bold,
														string italic, string regular);
        
 private:
  void check(char n);
  // Returns true if parameters have been set with optional arguments
  bool optargparams();
  
  map<char,Parameter> parameters;

  bool help_set;		// True if there is a parameter for getting help
  char help_param;  // Parameter for help
  
  // Stuff for man page
  string progname; // The name for the program (argv[0])
  unsigned man_numchapters; // Number of chapters in man page
  map<string,vector<string> > man_chapters;
  map<unsigned, string> manchapter_order;
};

#endif
