/***************************************************************************
                                  error.cpp 
                             -------------------

  Class for error handling

  __________________________________________________________________________

    begin                : Thu Oct 9 2003
    copyright            : (C) 2003 by W. Michael Brown
    email                : wmbrown@sandia.gov
 ***************************************************************************/

#include "error.h"
 
Notice::Notice() {
	nullout=new ostream(NULL);
	noteout=&cout;
	notice_level=10;
}

Notice::~Notice() {
	if (nullout!=NULL)
		delete nullout;
}

// Returns a null stream if level is two high, else returns notice stream
ostream & Notice::operator[] (const unsigned level) {
	if (level<notice_level)
		return *noteout;
	else
		return *nullout;
}

void Notice::setostream(ostream &out) {
	noteout=&out;
}

// Generate a notice to the program output
void Notice::set_notice_level(unsigned l) {
	notice_level=l;
}

void Notice::notice(unsigned level, string calling_class, string note) {
  if (level<notice_level)
    *noteout << calling_class << "::" << note;
}

void Notice::notice(unsigned level,string calling_class,vector<string> notes) {
  if (level<notice_level) {
    *noteout << calling_class << "::";
      for (unsigned i=0; i<notes.size(); i++)
        *noteout << notes[i];
  }
}

void Notice::notice(unsigned level, string note) {
  if (level<notice_level)
    *noteout << note;
}

void Notice::notice(unsigned level, vector<string> notes) {
  if (level<notice_level)
    for (unsigned i=0; i<notes.size(); i++)
      *noteout << notes[i];
}

Error::Error() {
	nullout=new ostream(NULL);
	unhandled_warnings=0;
	handled_warnings=0;
	max_level=10;

	handleatend=true;
  writetotalatend=true;

	errout=&cerr;
	logout=nullout;
}	
 
Error::~Error() {
	if (handleatend && unhandled_warnings!=0)
		writewarnings();
	if (writetotalatend && total_warnings()!=0)
		writetotals();
	if (nullout!=NULL)
		delete nullout;
}
	
// Set a log file for error AND notice output
void Error::set_logfile(ostream &out) {
	logout=&out;
	note.setostream(out);
}

// Total number of warnings
unsigned Error::total_warnings() {
	return unhandled_warnings+handled_warnings;
}

// See if an error with this ID exists
bool Error::operator[](unsigned id) {
	warning_iter m;
	m=warning_list.find(id);
	if (m==warning_list.end())
		return false;
  return true;
}

void Error::addwarning(unsigned ID, unsigned level, string calling_class,
											 string warning) {
  vector<string> message;
  message.push_back(warning);
  addwarning(ID,level,calling_class,message);
}
  
void Error::addwarning(unsigned ID, unsigned level, string calling_class, 
											 vector<string> warning) {
	ErrCom err;
	err.level=level;
	err.calling_class=calling_class;
	err.messages=warning;
  if (level>max_level)
		generate_error(ID, calling_class, err.messages);
	warning_list[ID].push_back(err);
	unhandled_warnings++;
}
											 
void Error::generate_error(unsigned ID, string calling_class,
													 string error) {
  vector<string> message;
  message.push_back(error);
  generate_error(ID,calling_class,message);
}

void Error::generate_error(unsigned ID, string calling_class, 
													 vector<string> error) {
	ErrCom err;
	err.level=max_level;
	err.calling_class=calling_class;
	err.messages=error;
	
	if (warnings()!=0)
		writewarnings();
	write_err(ID,err);
  //writetotals_e();
	//exit(1);
}
			
unsigned Error::warnings() {
	return unhandled_warnings;
}

void Error::write_err(unsigned ID, ErrCom err) {
	string errtype;

	//*errout << errtype << " ";
	//*logout << errtype << " ";
	if (ID!=0) {
		//*errout << ID << ": ";
		//*logout << ID << ": ";
	}
	//*errout << "(" << err.calling_class << ": " << err.level << ") ";
	//*logout << "(" << err.calling_class << ": " << err.level << ") ";

	*errout << "Error: ";
	*logout << "Error: ";

	for (unsigned i=0; i<err.messages.size(); i++) {
		*errout << err.messages[i];
		*logout << err.messages[i];
	}
	*errout << endl;
	*logout << endl;
	
	return;
}

void Error::writewarning(unsigned ID) {
 	for (unsigned i=0; i<warning_list[ID].size(); i++)
 		write_err(ID,warning_list[ID][i]);
	dismiss_warning(ID);
	return;
}

void Error::dismiss_warning(unsigned ID) {
	warning_iter m;
	m=warning_list.find(ID);
	if (m==warning_list.end())
		return;
	unhandled_warnings-=m->second.size();
  warning_list.erase(m);
}

void Error::writewarnings() {
	while (warning_list.size()>0)
		writewarning(warning_list.begin()->first);
	return;
}

void Error::dismiss_warnings() {
	while (warning_list.size()>0)
		dismiss_warning(warning_list.begin()->first);
	return;
}

// Write out the total warnings and errors
void Error::writetotals() {
	*errout << "____________________________________________________________"
					<< "__________\n"
					<< "Total warnings: " << handled_warnings+unhandled_warnings
				  << "\tTotal errors: 0\n\n";
	*logout << "____________________________________________________________"
					<< "__________\n"
					<< "Total warnings: " << handled_warnings+unhandled_warnings
				  << "\tTotal errors: 0\n\n";
}

// Write out the total warnings with one error
void Error::writetotals_e() {
	*errout << "____________________________________________________________"
					<< "__________\n"
					<< "Total warnings: " << handled_warnings+unhandled_warnings
					<< "\tTotal errors: 1\n\n";
	*logout << "____________________________________________________________"
					<< "__________\n"
					<< "Total warnings: " << handled_warnings+unhandled_warnings
					<< "\tTotal errors: 1\n\n";
}

