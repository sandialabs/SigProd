/***************************************************************************
                                  error.h 
                             -------------------

  Class for error handling

  __________________________________________________________________________

    begin                : Thu Oct 9 2003
    copyright            : (C) 2003 by W. Michael Brown
    email                : wmbrown@sandia.gov
 ***************************************************************************/

#ifndef ERRORCLASS
#define ERRORCLASS

#include <string>
#include <vector>
#include <map>
#include <iostream>

using namespace std;

// Error Levels:
//        0:  Errors expected to happen during normal execution
//      1-9:	Errors that a non-interactive program can handle and continue
//    10-19:  Errors that interactive program can handle (file not found,etc.)
//    20-  :  Serious errors that should terminate execution

struct ErrCom {
	unsigned level;
	string calling_class;
	vector<string> messages;
};
 
/// Notice Class for Handling Object Output
/** A notice object stores an ostream for output and a notice_level.
  * All output is sent along with a level.  Any output whose level is
  * not less than notice_level is sent to a null stream. The C++ output
  * operator '<<' can be used with the Notice operator '[]' which passes
  * the level:
  * \verbatim notice_object[29] << "This notice has level 29" << endl;
  * \endverbatim
  *
  * The guidelines for output notice levels are:
  * - \e     0: Information that must be output
  * - \e 1 - 9: Normal program output
  * - \e 10-19: Parameters useful for storing how the program was run
  * - \e 20-29: Extraneous information useful that may be useful to user
  * - \e 30-  : Debugging information */
class Notice {
 public:
  /// Standard output (cout) is the default notice output ostream
  /** The default maximum notice level is 9 \e (notice_level=10) */
  Notice();
  ~Notice();
  
  /// Set the output stream for notice output
  void setostream(ostream &out);
  
  /// Returns a null stream if level is two high, else returns notice stream
  ostream & operator[] (const unsigned level);
  
	/// Generate a notice to the program output
  void set_notice_level(unsigned l);
  void notice(unsigned level, string calling_class, string note);
	void notice(unsigned level, string calling_class, vector<string> notes);
	void notice(unsigned level, string note);
	void notice(unsigned level, vector<string> note);

 private:
  unsigned notice_level;

	ostream *nullout; // Null stream for redirecting output to nowhere
	ostream *noteout; // Output for notices
};

/// Error and Notice Handling
/** \b Error \b  Levels:
  *  - \e     0:  Errors expected to happen during normal execution
  *  - \e 1 - 9:	Errors that a non-interactive program can handle and continue
  *  - \e 10-19:  Errors that interactive program can handle (file not found,etc.)
  *  - \e 20-  :  Serious errors that should terminate execution 
  */
class Error {
 	public:
    Error();		 // Use cerr for output and no log file
		~Error();	

    /// Set a log file for error AND notice output
    void set_logfile(ostream &out);
			
		// See if an error with this ID exists
	  bool operator[](unsigned i);

	  // Add warnings, terminate if level is greater than max level
		void addwarning(unsigned ID, unsigned level, string calling_class,
										string warning);
		void addwarning(unsigned ID, unsigned level, string calling_class,
										vector<string> warning);
		
		// Add serious error (terminates execution)
		void generate_error(unsigned ID, string calling_class,
												string error);
		void generate_error(unsigned ID, string calling_class, 
												vector<string> error);
		
		// Number of Unhandled Warnings
		unsigned warnings();
		// Total number of warnings
		unsigned total_warnings();
		
		// Handle warning with this ID by writing it to out
		void writewarning(unsigned ID);
		// Handle warning with this ID without writing it
		void dismiss_warning(unsigned ID);
		// Handle all warnings by writing them out
		void writewarnings();
		// Handle all warnings without writing
		void dismiss_warnings();

		// Write out the total warnings with no error
		void writetotals();
		// Write out the total warnings with one error
		void writetotals_e();

		// For generating notices
    Notice note;
	private:
		map<unsigned,vector<ErrCom> > warning_list;
		typedef map<unsigned, vector<ErrCom> >::iterator warning_iter;
		unsigned handled_warnings;
		unsigned unhandled_warnings;
    bool handleatend;             // Write any unhandled errors on destruct
    bool writetotalatend;         // Write totals on destruct if not 0
		
		unsigned max_level; 					// if a warning has a level>max_level error!
		ostream *errout, *logout;			// Output for errors and warnings!
		ostream *nullout;             // No output

		void write_err(unsigned ID, ErrCom err);
};

#endif
