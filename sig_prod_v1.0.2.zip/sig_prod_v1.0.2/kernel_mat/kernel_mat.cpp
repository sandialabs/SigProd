// kernel_mat.cpp -- makes kernel matrices from seqeunces for use
// by the modified SVM^light code.
//
// Help regarding the program inputs can be obtained by
// typing "kernel_mat" with no arguments.
//
// The output of the program is a file which
// is of the form read by the modified SVM^light code.  
//
// This code is heavily modified from code produced by C. Churchwell.
// Additional code was provided by Mike Brown.
//
// S. Martin
// Original version: 4/17/04
// Released version: 9/17/04
// smartin@sandia.gov

#include <iostream>
#include <fstream>
#include <map>
#include <cstdlib>
#include <string>
#include <vector>
#include <algorithm>
#include <math.h>
#include "commandline.h"

#define VERSION "1.0"

using namespace std;

// Function prototypes:
void readseqs (string seq_filename, vector<string> &sequences);
void make_signatures (string sequence, int sig_height,
					  map<string,int> &desc_row);
void make_descmat (vector<string> &sequecnes, int sig_height,
				   vector< map<string,int> > &desc_mat);
void get_master_sigs (map<string, int> &master_sigs, vector< map<string,int> > &desc_mat1,
					  vector< map<string,int> > &desc_mat2, bool same_desc_mat, int throwaway);
void convert_descmat (map<string, int> &master_sigs, vector< map<string,int> > &desc_mat,
					  vector< map<int, int> > &desc_mat_num);
int computeInProd(map<int, int> &r, map<int, int> &c);

// Describe the program parameters
void Describe(CommandLine &cl);
// Parse the command line parameters
void HandleArgs(CommandLine &cl, int argc, char *argv[], Error *error);


int main(int argc, char *argv[])
{
	CommandLine cl;
	Error error;

	cout << endl;

      // Set up the arguments and parse the command line
	HandleArgs(cl,argc,argv,&error);

	// File information
	string seqfile1, seqfile2;
	string kermatfile;
	bool same_desc_mat = false;

	seqfile1 = cl.argstring(' ',0);
	if ( cl.argsize() < 3 )
	{
		cout << "Using same file for sequences1 and sequences2." << endl;
		seqfile2 = cl.argstring(' ',0);	// unnecessary
		same_desc_mat = true;
		kermatfile = cl.argstring(' ',1);
	}
	else
	{
		seqfile2 = cl.argstring(' ',1);
		kermatfile = cl.argstring(' ',2);
	}

      // ***************** Set parameters & defaults
	int sig_height = 1;
	bool normalization = true;
	bool sparse_output = false;
	int throwaway = 0;

	if ( cl['h'] )
		sig_height = cl.argint('h',0);

	if ( cl['u'] )
		normalization = false;

	if ( cl['s'] )
		sparse_output = true;

	if ( cl['t'] )
		throwaway = cl.argint('t',0);

	cout << "Using height "<< sig_height << "." << endl;

	if ( normalization )
		cout << "Normalization on." << endl;
	else
		cout << "Normalization off." << endl;

	if ( sparse_output )
		cout << "Output is sparse." << endl;
	else
		cout << "Output is full." << endl;

	cout << "Throw away signatures that occur <= " << throwaway << " times." << endl;
	cout << endl;

	// storage space for sequences
	vector<string> sequences1, sequences2;

	// --------------
	// read sequences

	cout << "Reading " << seqfile1 << " ..." << endl;
	readseqs (seqfile1,sequences1);
	cout << endl;

	if ( !same_desc_mat )
	{
		cout << "Reading " << seqfile2 << " ..." << endl;
		readseqs (seqfile2,sequences2);
	}

	cout << endl;

	// ---------------------------------
	// old fashioned descriptor matrices

	vector< map<string,int> > desc_mat1, desc_mat2;

	make_descmat (sequences1,sig_height,desc_mat1);

	if ( same_desc_mat )
	{
		cout << "Using idential descriptor matrices." << endl;
		desc_mat2 = desc_mat1;
	}
	else
		make_descmat (sequences2,sig_height,desc_mat2);
	cout << endl;


	// --------------------------------------------------------
	// convert to numerical format (for faster matrix multiply)

	map<string, int> master_sigs;
	vector< map<int,int> > desc_mat1_num, desc_mat2_num;

	get_master_sigs (master_sigs,desc_mat1,desc_mat2,same_desc_mat,throwaway);
	convert_descmat (master_sigs,desc_mat1,desc_mat1_num);

	if ( same_desc_mat )
	{
		cout << "Using idential numerical descriptor matrix conversion." << endl;
		desc_mat2_num = desc_mat1_num;
	}
	else
		convert_descmat (master_sigs,desc_mat2,desc_mat2_num);
	cout << endl;

	// ------------------------------------------
	// compute diagonal entries for normalization

	cout << "Computing diagonal entries ..." << endl;

	vector<float> desc_mat1_diag, desc_mat2_diag;

	unsigned i;
	for (i = 0; i < desc_mat1_num.size(); i++)
		if ( normalization )
			desc_mat1_diag.push_back(computeInProd(desc_mat1_num[i],desc_mat1_num[i]));
		else
			desc_mat1_diag.push_back(1);

	for (i = 0; i < desc_mat2_num.size(); i++)
		if ( normalization )
			desc_mat2_diag.push_back(computeInProd(desc_mat2_num[i],desc_mat2_num[i]));
		else
			desc_mat2_diag.push_back(1);

	cout << endl;

	// -----------------------------------
	// compute and write out kernel matrix

	ofstream kermat_out(kermatfile.c_str());
	if (!kermat_out)
	{
		cerr << "Could not open " << kermatfile << endl;
		exit(1);
	}

	kermat_out << "SIZE\t" << desc_mat1.size() << "\t" << desc_mat2.size() << endl;
  	kermat_out << "SPARSE\t" << sparse_output << endl;
	kermat_out << "SYMMETRIC\t" << same_desc_mat << endl;

	cout << "Computing kernel matrix ...";

	float InProdTemp;
	for (i = 0; i < desc_mat1.size(); i++)
	{
		for (unsigned int j = 0; j < desc_mat2.size(); j++)
		{
			InProdTemp = (float)(computeInProd (desc_mat1_num[i],desc_mat2_num[j]))/
						   sqrt ( desc_mat1_diag[i] * desc_mat2_diag[j] );
			if ( sparse_output )
			{
				if ( InProdTemp > 0 )
					if ( !same_desc_mat )
						kermat_out << i << "\t" << j << "\t" << InProdTemp << "\n";
					else if ( i <= j )
						kermat_out << i << "\t" << j << "\t" << InProdTemp << "\n";
			}
			else
				if ( !same_desc_mat )
					kermat_out << InProdTemp << "\t";
				else if ( i <= j )
					kermat_out << InProdTemp << "\t";
		}
		if ( !sparse_output )
			kermat_out << endl;

		if ( (i % 100) == 0)
			cout << i;
		cout << ".";
	}
	kermat_out << "END" << endl;

	kermat_out.close();

	cout << endl << "Successfull termination: goodbye!" << endl;
}

void readseqs (string seqs_filename, vector<string> &sequences)
{
	// read sequences (one per line)
	string next_seq;

	// make sure sequences is empty
	sequences.erase (sequences.begin(), sequences.end());

	ifstream seqs_in (seqs_filename.c_str());
	if (!seqs_in)
	{
		cerr << "Error: could not open " << seqs_filename << "." << endl;
		exit(1);
	}

	cout << "Reading sequences ..." << endl;

	int num_seqs_read = 0;
	while ( getline(seqs_in, next_seq) )
	{
		sequences.push_back(next_seq);
		num_seqs_read++;
	}

	seqs_in.close();

	cout << "Read " << num_seqs_read << " sequences." << endl;
	cout << "First 3 sequences: " << endl
		 << sequences[0].substr(0,9) << " ..." << endl
		 << sequences[1].substr(0,9) << " ..." << endl
		 << sequences[2].substr(0,9) << " ..." << endl;
}

void make_signatures( string sequence, int sig_height, 
					  map <string,int> &desc_row )
{
	// makes signatures from passed sequence,
	// returns as a single row of a descriptor matrix

	// Assumes: sequence is linear, composed of 1-letter 
	// amino acid designations.
	// Discards end signatures with only one child.

	vector<string> sigs, unique_sigs;
	int i, j;

	for (i = sig_height; i < sequence.size() - sig_height; i++)
		{
			string parent, left, right;

			left = "";
			for (j = i-1; j >= i-sig_height; j--)
				left += sequence[j];
			
			right = "";
			for (j = i+1; j <= i+sig_height; j++)
				right += sequence[j];

			// canonize signature
			parent = sequence[i];
			if (left <= right)
				parent += (left + right);
			else
				parent += (right + left);

			// Push signature onto sigs vector
			sigs.push_back(parent);
		}

	sort(sigs.begin(), sigs.end());

	// Get the occurence of each signature, store in row of matrix
	unique_copy(sigs.begin(), sigs.end(), back_inserter(unique_sigs));
	for (unsigned int j = 0; j < unique_sigs.size(); j++)
	{
		int occ = count(sigs.begin(), sigs.end(), unique_sigs[j]);
		desc_row.insert(map<string, int>::value_type(unique_sigs[j], occ));
	}
}

void make_descmat (vector<string> &sequences, int sig_height,
				   vector < map<string,int> > &desc_mat)
{
	map<string,int> desc_row;
	cout << "Making descriptor matrix ...";
	for (unsigned int i = 0; i < sequences.size(); i++)
	{
		desc_row.erase ( desc_row.begin(), desc_row.end() );
		make_signatures ( sequences[i], sig_height, desc_row );
		if ( (i % 100) == 0 )
			cout << i;
		cout <<  ".";
		desc_mat.push_back(desc_row);
	}
	cout << endl;
}

void get_master_sigs (map <string, int> &master_sigs, vector< map<string, int> > &desc_mat1,
					  vector< map<string,int> > &desc_mat2, bool same_desc_mat, int throwaway)
{
	unsigned i;
	cout << "Collating all signatures ..." << endl;

	map <string, int> all_master_sigs;

	map<string, int>::iterator j;
	for (i = 0; i < desc_mat1.size(); i++)
		for (j = desc_mat1[i].begin(); j != desc_mat1[i].end(); j++)
			if ( all_master_sigs.find( j->first ) == all_master_sigs.end() )
				all_master_sigs.insert(map<string, int>::value_type(j->first,1));
			else
				all_master_sigs[ j-> first ] = all_master_sigs [ j->first ] + 1;

	if ( !same_desc_mat )
		for (i = 0; i < desc_mat2.size(); i++)
			for (j = desc_mat2[i].begin(); j != desc_mat2[i].end(); j++)
				if ( all_master_sigs.find( j->first ) == all_master_sigs.end() )
					all_master_sigs.insert(map<string, int>::value_type(j->first,1));
				else
					all_master_sigs[ j-> first ] = all_master_sigs [ j->first ] + 1;

	// throw away variables that occur only a few times
	master_sigs.erase (master_sigs.begin(),master_sigs.end());
	int count_throwaway = 0;
    for (j = all_master_sigs.begin(); j != all_master_sigs.end(); j++)
		if ( j->second > throwaway )
			master_sigs.insert (map<string, int>::value_type (j->first,1));
		else
			count_throwaway++;

	cout << "Threw away " << count_throwaway << " signatures." << endl;

	if ( master_sigs.size () == 0 )
	{
		cout << "Error (stopping program): eliminated all signatures!" << endl;
		exit(1);
	}

	int count_master_sigs = 0;
	for (j = master_sigs.begin(); j != master_sigs.end(); j++)
		j->second = count_master_sigs++;

	cout << "Kept " << master_sigs.size() << " signatures." << endl;
	cout << endl;
}

int computeInProd(map<int, int> &r, map<int, int> &c)
{
	map<int, int>::const_iterator r_iter, c_iter;
	// Go through row map and if the same signature appears
	// in the columns map, then multiply the occurrence numbers
	// and store it.
	
	int innprod = 0;
	for (r_iter = r.begin(); r_iter != r.end(); r_iter++)
	{
		c_iter = c.find(r_iter->first); 
		if (c_iter != c.end())
		{
			innprod += r_iter->second * c_iter->second;
		}
	}
	return innprod;	
}

void convert_descmat (map<string, int> &master_sigs, vector< map<string,int> > &desc_mat,
					  vector< map<int, int> > &desc_mat_num)
{
	cout << "Converting to numerical form ..." << endl;

	map<int,int> desc_row_num;
	map<string,int>::iterator j;
	for (unsigned int i = 0; i < desc_mat.size(); i++)
	{
		desc_row_num.erase (desc_row_num.begin(), desc_row_num.end());
		for (j = desc_mat[i].begin(); j != desc_mat[i].end(); j++)
		{
			desc_row_num.insert ( map<int,int>::value_type
					( master_sigs[j->first], j->second ) );
		}
		desc_mat_num.push_back(desc_row_num);
	}
}

void Describe(CommandLine &cl) {

	string name=cl.program_name();
	string version="V"+string(VERSION);

		cout << name << " " << version << endl;
		cout << "---------------" << endl;
		cout << endl << "Copyright: S. Martin, smartin@sandia.gov" << endl;
		cout << endl << "This software is available for non-commercial use only and must not";
		cout << endl << "be modified or distributed without permission.  The author assumes";
		cout << endl << "no liability for the performance or accuracy of this software.";
		cout << endl << endl;
		cout << "Usage: kernel_mat sequences1 sequences2 kernelmat [options]" << endl;
		cout << endl;
		cout << "Arguments:" << endl;
		cout << "  sequences1 -- text file with one protein amino acid sequence per line";
		cout << endl << "  sequences2 -- second protein sequence file (optional)";
		cout << endl << "  kernelmat -- output resulting kernel matrix to this file";
		cout << endl << endl;
		cout << "Options:";
		cout << endl << "  -h [pos. int] gives signature height to use (default 1).";
		cout << endl << "  -t [pos. int] tells the program to throw away signatures";
		cout << endl << "                occur <= 0, 1, 2, etc. times (default 0).";
		cout << endl << "  -u to avoid normalization (default is to normalize).";
		cout << endl << "  -s to use sparse output.";
		cout << endl << endl;
		cout << "For details see:";
		cout << endl << "  S. Martin, D. Roe, and J.-L. Faulon, Predicting Protein-Protein";
		cout << endl << "  Interactions using Signature Product, Bioinformatics, 2004." << endl;
		exit(1);
}

void HandleArgs(CommandLine &cl, int argc, char *argv[], Error *error) {

  // Two arguments are mandatory and one is optional.
	cl.addmanditory(' ',3,2);
	
  // Flag
	cl.add('h',1);
	cl.add('t',1);
	cl.add('u',0);
	cl.add('s',0);
  


	  // ------------------------------ Man Page --------------------------------------
	
	// Short Description
  cl.addtoman_chapter("NAME","Example program for commandline");

  // Version
  cl.addtoman_chapter("VERSION","Version "+string(VERSION));

  // Full Description
  const string desc[2]={
		"This is an example program for use of the commandline ",
		"class."};
	cl.addtoman_chapter("DESCRIPTION",2,desc);

  // Authors
	cl.addtoman_chapter("AUTHORS","W. Michael Brown");

  
	// --------------------------- Parse the Command Line ---------------------------
	
	// Parse the commandline
  if (!cl.parse(argc,argv,error)) {
		error->generate_error(0,a::filenameonly(argv[0]),"Bad Command Line\n");
		Describe(cl);
	}
}
