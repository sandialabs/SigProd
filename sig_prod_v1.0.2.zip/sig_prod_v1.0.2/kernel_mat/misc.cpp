/****************************************************************************
 * misc.cpp
 *    Miscellaneous Functions that do not deserve their own class
 *
 * W. Michael Brown
 * 5/30/03
 ****************************************************************************/

#include "misc.h"

ifstream & a::fileopen(ifstream &in, char *filename, Error &error) {
  in.clear();
  in.open(filename);
  if (!in) {
    error.addwarning(1,15,"Misc",
										 "Could not open "+string(filename)+" for input!\n");
    error.writewarnings();
  }
  return in;
}

ifstream & a::fileopen(ifstream &in, string filename, Error &error) {
  in.clear();
  in.open(filename.c_str());
  if (!in) {
    error.addwarning(1,15,"Misc",
										 "Could not open "+string(filename)+" for input!\n");
    error.writewarnings();
  }
  return in;
}

ofstream & a::fileopen(ofstream &out, const char *filename, Error &error) {
  out.clear();
  out.open(filename);
  if (!out) {
    error.addwarning(2,15,"Misc",
										 "Could not open "+string(filename)+" for output!\n");
    error.writewarnings();
  }
  return out;
}

ofstream & a::fileopen(ofstream &out, string filename, Error &error) {
  out.clear();
  out.open(filename.c_str());
  if (!out) {
    error.addwarning(2,15,"Misc",
										 "Could not open "+string(filename)+" for output!\n");
    error.writewarnings();
  }
  return out;
}

string a::date() {
	char datestr[40];

	time_t t;
	time(&t);

	strftime(datestr,40,"%B %d, %Y",localtime(&t));
	return string(datestr);
}

// Return the filename without the extension
string a::namewoext(string filename) {
  return (filename.substr(0,filename.find('.')));
}

// Return the filename without extension or directory
string a::filenameonly(string filename) {
	// Find the start of the filename
	unsigned start=0;
 	if (filename.find_last_of('/')<(filename.length()-1))
 		start=filename.find_last_of('/')+1;

	// Find the end of the filename
	unsigned end=filename.find('.')-start;
	return(filename.substr(start,end));
}

// Return the extension of a filename
string a::extension(string filename) {
	// Find the start of the extension
	unsigned start=filename.find_last_of('.')+1;
	if (start>=filename.length())
		return "";

	return filename.substr(start,filename.length()-start);
}

// Center a string over the specified length
string a::strcenter(string s, unsigned length) {
	string empty("                                                           ");
  unsigned half=length/2;
  unsigned spacer=half-(s.length()/2)-1;
  return (empty.substr(0,spacer)+s);
}

// True if a character is whitespace
bool a::whitespace(char c) {
	if (c==' ' || c=='\n' || c=='\t' || c=='\f' || c=='\r' || c=='\v')
		return true;
	return false;
}

// Check if a string is only whitespace
bool a::whitespace(string s) {
  for (unsigned i=0; i<s.length(); i++)
  	if (!whitespace(s[i]))
  		return false;
  return true;
}

/// Remove all whitespace from a string
string a::remove_whitespace(string s) {
	string n;
	for (unsigned i=0; i<s.length(); i++)
		if (!whitespace(s[i]))
			n+=s[i];
	return n;
}

void a::str_replace(string source, string target, string &s) {
	unsigned slength=source.length();
	unsigned tlength=target.length();
	unsigned loc=0;

	#ifdef DEBUG
	assert(slength>0 && tlength>0);
	#endif
	
	while (true) {
		if (loc>=s.length())
			break;
		loc=s.find(source,loc);
		if (loc>=s.length())
			break;
		s.replace(loc,slength,target,0,tlength);
		loc+=tlength;
	}
}

/// Convert all alpha characters to lower case
string a::tolower(string s) {
	string r="";
	for (unsigned i=0; i<s.length(); i++)
		r+=std::tolower(s[i]);
	return r;
}

// Return a string of num underscores
string a::underline(unsigned num) {
	return string(num,'_');
}

// The tokens parsed from cstring are \e added to the input vector
void a::get_tokens(char *line, vector<string> &tokens) {
	string sline=line;
	string token="";
	unsigned i=0;
	while (i<sline.length()) {
		if (whitespace(sline[i])) {
      i++;
			continue;
		}
		while (i<sline.length()) {
			if (whitespace(sline[i])) {
				tokens.push_back(token);
				token="";
				break;
			}
			token+=sline[i];
			i++;
		}
	}
	if (token!="")
		tokens.push_back(token);
}
		

string a::itoa(unsigned i) {
	ostringstream o;
	o << i;
	return o.str();
}

string a::itoa(int i) {
	ostringstream o;
	o << i;
	return o.str();
}

string a::ftoa(double i) {
	ostringstream o;
	o << i;
	return o.str();
}

double a::square(double num) {
	return num*num;
}

// Rounds a number
double a::round(double n) {
	double r=ceil(n);
	if (r-n>0.5)
		return floor(n);
	return r;
}

// Seed the random number generator
void a::seedrandom(unsigned seed) {
	srandom(seed);
}

// Seed the random number generator with the current time
void a::seedrandom_time() {
	srandom(unsigned(time(0))); //+getpid());
}

// Return an integer between 0 and max
unsigned a::irandom(unsigned max) {
	return unsigned(double(random())/double(RAND_MAX)*max);
}

// Return an integer between 0 and max
long a::lrandom(long max) {
	return long(double(random())/double(RAND_MAX)*max);
}

double a::frandom(double max) {
	return (double(random())/double(RAND_MAX)*max);
}

// --------------------- Finite Precision stuff
double a::epsilon(double number) {   // Finite Precision zero
	return fabs(DBL_EPSILON*number);
}

// Bring number 1 digit closer to zero
double a::minus_eps(double number) {
  return (number-DBL_EPSILON*number);
}

// Bring number 1 digit away from zero
double a::plus_eps(double number) {
  return (number+DBL_EPSILON*number);
}

 // Bring number m digits away from zero
double a::plus_Meps(double m,double number) {
	return (number+m*DBL_EPSILON*number);
}

// Bring number precision/2.0 digits away
double a::plus_2eps(double number) {
	return (number+100000000*DBL_EPSILON*number);
}

// Bring number pre/2 digits away
double a::minus_2eps(double number) {
	return (number-100000000*DBL_EPSILON*number);
}
// Not a number checks
bool a::not_nan(double number) {     // False if NAN
	if (number-number!=0)
		return false;
	return true;
}

// Specify the filename format
FileIterator::FileIterator(string h,string e,unsigned d) {
	file_num=0;
	digits=d;
	header=h;
	extension=e;
}

string FileIterator::nextfilename() {
  // Get an output filename from a string
  string filename;
  filename=a::itoa(file_num);
  while (filename.length()<digits)
		filename='0'+filename;
  file_num++;
  return header+'.'+filename+'.'+extension;
}
