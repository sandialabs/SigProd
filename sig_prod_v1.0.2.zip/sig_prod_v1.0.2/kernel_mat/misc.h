/****************************************************************************
 * misc.h
 *    Miscellaneous Functions that do not deserve their own class
 *
 * W. Michael Brown
 * 5/30/03
 ****************************************************************************/

#ifndef MISC
#define MISC

#include "error.h"
#include <fstream>
#include <sstream>
#include <iostream>
#include <string>
#include <stdlib.h>
#include <float.h>
#include <time.h>
#include <math.h>
#include <unistd.h>

using namespace std;

/// Miscellaneous functions that do not deserve their own class
/** \e a contains functions for \n
  * - fileio 
  * - string manipulation
  * - conversion from numbers to strings
  * - simple math functions
  * - finite precision stuff */
namespace a {
	/// Open a file for input. Generates error ID \b 1 on fail.
	ifstream & fileopen(ifstream &in, char *filename, Error &error);
	/// Open a file for input. Generates error ID \b 1 on fail.
	ifstream & fileopen(ifstream &in, string filename, Error &error);

	/// Open a file for input. Generates error ID \b 2 on fail.
	ofstream & fileopen(ofstream &out, string filename, Error &error);
	/// Open a file for input. Generates error ID \b 2 on fail.
	ofstream & fileopen(ofstream &out, const char *filename, Error &error);

  /// Get the current date in the format "January 1, 2003"
  string date();
	
	/// Returns the filename without the extension
	string namewoext(string filename);
	/// Returns the filename without extension or directory
	string filenameonly(string filename);
	/// Return the extension of a filename
	string extension(string filename);
	/// Centers a string over the specified length
	string strcenter(string s, unsigned length);
  /// True if a character is whitespace
  bool whitespace(char c);
	/// True if a string is only whitespace
	bool whitespace(string s);
	/// Remove all whitespace from a string
	string remove_whitespace(string s);
	/// Replace any instance of \e source with \e target within the string \e s
	void str_replace(string source, string target, string &s);
  /// Convert all alpha characters to lower case
  string tolower(string s);
	
  /// The tokens parsed from cstring are \e added to the input vector
  /** \param line The line with 'white space' delimeted tokens
    * \param tokens Each token parsed is added to the vector */
  void get_tokens(char *line, vector<string> &tokens);
  
  /// Return a string of num underscores
  string underline(unsigned num);
	
	/// Returns string representation of unsigned number
	string itoa(unsigned i);
	/// Returns string representation of int number
	string itoa(int i);
	/// Returns string representation of double number
	string ftoa(double i);

	/// Returns the square of a number
	double square(double);
	/// Rounds a number
	double round(double);

	/// Seed the random number generator
	void seedrandom(unsigned seed);
	/// Seed the random number generator with the current time
	void seedrandom_time();
	/// Returns a random integer between 0 and max
	unsigned irandom(unsigned max);
	/// Returns a random integer between 0 and max
	long lrandom(long max); 
	/// Returns a random double between 0 and max
 	double frandom(double max);

	// Finite Precision stuff

	/// Returns a number representing zero for finite checks
	double epsilon(double number);
  /// Returns number closer to zero by the smallest interval possible
	double minus_eps(double number); 
	/// Returns number farther from zero by the smallest interval possible
	double plus_eps(double number);
 	/// Returns number farther from zero by smallest interval * \b m
	double plus_Meps(double m,double number);
  /// Returns number farther from zero by smallest interval * 10^8
	double plus_2eps(double number);
  /// Returns number closer to zero by smallest interval * 10^8
	double minus_2eps(double number);

	/// Returns false if the number is stored as NAN
	bool not_nan(double number);
};

/// Iterate through file names to give each unique numbers
class FileIterator {
 public:
  /// Specify the filename format
  /** Files are generated according to the following format:
    * \verbatim header.%0'digits'file_number.extension \endverbatim */
	FileIterator(string header,string extension,unsigned digits);
  /// Returns the next filename.
  string nextfilename();
 private:
  FileIterator(); 					// Declare away
  string header,extension;
  unsigned digits;
  unsigned file_num;	
};

#endif
