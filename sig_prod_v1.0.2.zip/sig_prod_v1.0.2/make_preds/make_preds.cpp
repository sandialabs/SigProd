// make_preds -- make protein-protein interaction predictions by extrapolating
// from one species to another.
//
// S. Martin, 9/22/04

#include <iostream>
#include "oneDsparse.h"
#include <stdio.h>
#include <fstream>
#include <cstdlib>
#include <math.h>
#include <string.h>

using namespace std;

# define Y2H_SHAWN_SIZE			     200000
// This is also defined in svm_common.h!

// Globals
float zero=0.0;
OneDSparse ker_mat(zero);    // kernel matrix

int examples[Y2H_SHAWN_SIZE][2];    // pairs indices
int num_examples;

char kernel_type[50];               // svm model information
double b, svm_gamma;      
float alphay[Y2H_SHAWN_SIZE];

// Function prototypes:
void readkermat (char* ker_filename);
void readexamples (char* ex_filename);
void readmodel (char* model_filename);
double compute_ker (int i, int j, int k);

int main (int argc, char *argv[])
{
    cout << endl;

	// check for appropriate number of inputs
	if (argc != 5)
	{
		cout << "make_preds" << endl;
		cout << "----------" << endl;
		cout << endl << "Copyright: S. Martin, smartin@sandia.gov" << endl;
		cout << endl << "This software is available for non-commercial use only and must not";
		cout << endl << "be modified or distributed without permission.  The author assumes";
		cout << endl << "no liability for the performance or accuracy of this software.";
		cout << endl << endl;
		cout << "Usage: make_preds kermat pairs model predictions" << endl;
		cout << endl;
		cout << "Arguments:" << endl;
		cout << "  kermat -- kernel matrix output from kernel_mat.exe";
		cout << endl << "  pairs -- pair indices";
		cout << endl << "  model -- model output from svm_light";
		cout << endl << "  predictions -- interaction predictions (output from this program)";
		cout << endl << endl;
		cout << "For details see:" << endl;
		cout << endl << "  S. Martin, D. Roe, and J.-L. Faulon, Predicting Protein-Protein";
		cout << endl << "  Interactions using Signature Product, Bioinformatics, 2004." << endl << endl;
		exit(1);
	}

	// read kernel matrix
	readkermat (argv[1]);
	
    // read pairs
	readexamples (argv[2]);
	
	// read model
	readmodel (argv[3]);
	
	// now make predictions
	ofstream preds_out(argv[4]);
	if (!preds_out)
	{
		cerr << "Error: could not open " << argv[4] << endl;
		exit(1);
	}
	
	preds_out << "SIZE\t" << ker_mat.columns() << "\t" << ker_mat.columns() << endl;
	preds_out << "SYMMETRIC\t1"  << endl;
	
	cout << "Making predictions ...";
	
    double pred;
	int i, j, k;
	
	for (i = 0; i < ker_mat.columns(); i++)	// note: kermat_cols is = num_preds
	{
		for (j = i; j < ker_mat.columns(); j++)
		{
			for (k = 0, pred = 0.0; k < num_examples; k++)
				pred = pred + alphay[k] * compute_ker(i,j,k);
			pred = pred - b;
			preds_out << pred << "\t";
		}
		preds_out << endl;
		
  
        if ( (i % 100) == 0)
			cout << i;
		cout << "."; fflush(stdout);
	}

	cout << endl << "Successful termination: goodbye!" << endl << endl;
}

void readkermat (char* ker_filename)
{
	// read kernel matrix -- kernel mat has the
	// form returned by kernel_mat.exe
	
	ifstream kermat_in (ker_filename);
	if (!kermat_in)
	{
		cerr << "Error: could not open " << ker_filename << endl;
		exit(1);
	}
 
    // read kernel matrix
    cout << "Reading kernel matrix..."; fflush (stdout);
    
    ker_mat.read(kermat_in);
	kermat_in.close();

    cout << "Done" << endl;
    cout << "Read " << ker_mat.rows() << " x " << ker_mat.columns() << " kernel matrix." << endl;
    
    printf("First 3 x 3 submatrix is:\n%f %f %f\n%f %f %f\n%f %f %f\n",
	ker_mat(0,0),ker_mat(0,1),
	ker_mat(0,2),ker_mat(1,0),
	ker_mat(1,1),ker_mat(1,2),
	ker_mat(2,0),ker_mat(2,1),
	ker_mat(2,2));
}

void readexamples (char* ex_filename)
{
	// read examples from ex_filename
	// file is in format line 1 = numexamples
	// remaining lines are pairs of examples

	ifstream examples_in (ex_filename);
	if (!examples_in)
	{
		cerr << "Error: could not open " << ex_filename << endl;
		exit(1);
	}

	examples_in >> num_examples;

	if (num_examples > Y2H_SHAWN_SIZE)
	{ 
		cerr << "Error: number pairs exceeds allowed memory." << endl;
		exit(1);
	}

	cout << "Reading pairs ..." << endl;

	for (int i = 0; i < num_examples; i++)
		examples_in >> examples[i][0] >> examples[i][1];

	cout << "First three pairs are: " << endl;
	cout << examples[0][0] << "\t" << examples[0][1] << endl;
	cout << examples[1][0] << "\t" << examples[1][1] << endl;
	cout << examples[2][0] << "\t" << examples[2][1] << endl;

	examples_in.close();
}

void readmodel (char* model_filename)
{
	// readmodel -- reads in model from file
	// produced by svm light
	
    FILE *modelin;

    if ((modelin = fopen (model_filename, "r")) == NULL)
   	{
		cerr << "Error: could not open " << model_filename << endl;
		exit(1);
	}
	
	// read parameters	
    char svm_version[100];
    long svm_kernel_type,num_svs,long_junk;
    double double_junk;
    double alpha;
    long alpha_ind;
    
    cout << "Reading model file ..."; fflush(stdout);
    
    fscanf(modelin,"SVM-light Version %s\n",svm_version);
    if(strcmp(svm_version,"V5.00")) {
      cerr << "Error: version of model file is not 5.00!" << endl; 
      exit (1); 
    }
    
    fscanf(modelin,"%ld%*[^\n]\n", &svm_kernel_type);  
    if ( svm_kernel_type != 4 ) {
      cerr << "Error: model file was not generated using patched svm light." << endl;
      exit(1);
    }
    
    fscanf(modelin,"%ld%*[^\n]\n", &long_junk);
    fscanf(modelin,"%lf%*[^\n]\n", &svm_gamma);    
    fscanf(modelin,"%lf%*[^\n]\n", &double_junk);
    fscanf(modelin,"%lf%*[^\n]\n", &double_junk);
    fscanf(modelin,"%[^#]%*[^\n]\n", kernel_type);
    
    fscanf(modelin,"%ld%*[^\n]\n", &long_junk);
    fscanf(modelin,"%ld%*[^\n]\n", &long_junk);;
    fscanf(modelin,"%ld%*[^\n]\n", &num_svs);
    fscanf(modelin,"%lf%*[^\n]\n", &b);
 
    // initialize alphay
    for (unsigned i = 0; i < num_examples; i++)
        alphay[i] = 0;
        
    // now read in alphays
    for (unsigned i = 1; i<num_svs; i++)
    {
        fscanf(modelin,"%lf %ld:%ld\n", &alpha, &long_junk, &alpha_ind);
        alphay[alpha_ind] = alpha;
    }
    
	cout << endl << "Kernel type: " << kernel_type;
    if ( strcmp(kernel_type,"rbf") == 0 )
        cout << " with gamma = " << svm_gamma;
    cout << endl << "Threshold: b = " << b << endl;
 	cout << "alpha_0 = " << alphay[0] << endl;
	cout << "alpha_1 = " << alphay[1] << endl;
	cout << "alpha_2 = " << alphay[2] << endl;
    
	fclose(modelin);
}

double compute_ker (int i, int j, int k)
{
    double xdotx, xdoty, ydoty;
    double kernel_answer;
    
    if ( strcmp(kernel_type,"asym") == 0)
	  {
	  /* asymetric kernel */
	  kernel_answer = (ker_mat (examples[k][0], i) *
		 ker_mat (examples[k][1], j));
      }

    if ( strcmp(kernel_type,"sym") == 0 )
      {
	  /* symmetric kernel */
 	  kernel_answer = 2.0*
		(ker_mat (examples[k][0], i) *
		 ker_mat (examples[k][1], j) + 
		 ker_mat (examples[k][0], j) *
		 ker_mat (examples[k][1], i));
	  }

    if (strcmp(kernel_type,"rbf") == 0 )
	  {
	  /* rbf modification */
	  xdoty = 2.0*
		(ker_mat (examples[k][0], i) *
		 ker_mat (examples[k][1], j) + 
		 ker_mat (examples[k][1], i) *
		 ker_mat (examples[k][0], j));

 	  xdotx = 2.0*
		(ker_mat (examples[k][0], examples[k][0]) *
		 ker_mat (examples[k][1], examples[k][1]) + 
		 ker_mat (examples[k][1], examples[k][0]) *
		 ker_mat (examples[k][0], examples[k][1]));

	  ydoty = 2.0*
		(ker_mat (i, i) *
		 ker_mat (j, j) + 
		 ker_mat (i, j) *
		 ker_mat (j, i));

	  kernel_answer = exp(-svm_gamma*(xdotx-2*xdoty+ydoty));
	  }
    return(kernel_answer);
}
