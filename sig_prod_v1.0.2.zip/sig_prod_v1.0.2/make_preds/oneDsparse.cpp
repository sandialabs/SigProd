/***************************************************************************
                                oneDsparse.cpp
                             -------------------
                               W. Michael Brown

	1 Dimensional Sparse Matrix
	Insert/Access in log(N)

 __________________________________________________________________________
    This file is part of the Math Library
 __________________________________________________________________________

    begin                : Mon May 24 2003
    copyright            : (C) 2004 by W. Michael Brown
    email                : wmbrown@sandia.gov
 ***************************************************************************/

#include "oneDsparse.h"

 
// Initialize matrix and set the zero value for 'empty cells'
OneDSparse::OneDSparse(mtype &zero) {
	zerovalue=zero;
	symmetric=false;
	sparse=true;
}

// Initialize matrix with a 2-D size and set zero value for 'empty cells'
OneDSparse::OneDSparse(bool sym, bool sparsem, unsigned rows, 
																 unsigned columns, mtype &zero){
	size_set=true;
	symmetric=sym;
	sparse=sparsem;
	ncolumns=columns;
	nrows=rows;
	zerovalue=zero;
	if (sparse==false)
		if (symmetric==false)
			fmatrix=new mtype[nrows*ncolumns];
		else
			fmatrix=new mtype[nrows*(nrows+1)/2];
}

// Clear the matrix
void OneDSparse::clear() {
	if (sparse==false)
		delete[] fmatrix;
	matrix.clear();
	size_set=false;
	symmetric=false;
	sparse=true;
}

// Test if the matrix is empty
bool OneDSparse::empty() {
	return matrix.empty();
}

// Set the size for the matrix
void OneDSparse::size(unsigned rows, unsigned columns) {
	size_set=true;
	ncolumns=columns;
	nrows=rows;
}

// Get the number of columns in the matrix
unsigned OneDSparse::columns() {
	#ifdef DEBUG
	assert(size_set);
	#endif
	return ncolumns;
}

// Get the number of rows in the matrix
unsigned OneDSparse::rows() {
	#ifdef DEBUG
	assert(size_set);
	#endif
	return nrows;
}

// 1-D access for a cell
mtype& OneDSparse::operator[] (const unsigned i) {
	if (sparse) {
		Miter m;
		m=matrix.find(i);
		if (m==matrix.end())
			return zerovalue;
		else
			return m->second;
	}
	return fmatrix[i];
}

// 2-D access for a cell
mtype& OneDSparse::operator() (const unsigned row,
																						const unsigned col) {
	#ifdef DEBUG
	assert(size_set);
	assert(col<ncolumns);
	assert(row<nrows);
	#endif
	unsigned onedi;
	if (symmetric) {
 		if (row>col)
 		  onedi=row+unsigned(ncolumns*col+col/2.0-(col*col)/2.0)-col;
	  else
	    onedi=col+unsigned(ncolumns*row+row/2.0-(row*row)/2.0)-row;
  } else
    onedi=row*ncolumns+col;
	return (*this)[onedi];	
}

// 1-D set for the value of a cell
void OneDSparse::set(const unsigned i, const mtype &value) {
	if (sparse)
		matrix[i]=value;
	else
		fmatrix[i]=value;
}

// 2-D set for the value of a cell
void OneDSparse::set(const unsigned row, const unsigned col,
															 const mtype &value) {
	#ifdef DEBUG
	assert(size_set);
	assert(col<ncolumns);
	assert(row<nrows);
	#endif
	unsigned onedi;
	if (symmetric) {
 		if (row>col)
 		  onedi=row+unsigned(ncolumns*col+col/2.0-(col*col)/2.0)-col;
	  else
	    onedi=col+unsigned(ncolumns*row+row/2.0-(row*row)/2.0)-row;
  } else
    onedi=row*ncolumns+col;
	set(onedi,value);
}

// Set the value of a cell to 'zero' using 1D access
void OneDSparse::zero(const unsigned i) {
	if (sparse) {
		Miter m;
		m=matrix.find(i);
		if (m!=matrix.end())
			matrix.erase(m);
	} else
	set(i,zerovalue);
}

// Set the value of a cell to 'zero' using 2D access
void OneDSparse::zero(const unsigned row, const unsigned col) {
	#ifdef DEBUG
	assert(size_set);
	assert(col<ncolumns);
	assert(row<nrows);
	#endif
	unsigned onedi;
	if (symmetric) {
 		if (row>col)
 		  onedi=row+unsigned(ncolumns*col+col/2.0-(col*col)/2.0)-col;
	  else
	    onedi=col+unsigned(ncolumns*row+row/2.0-(row*row)/2.0)-row;
  } else
    onedi=row*ncolumns+col;
	zero(onedi);
}

// Write out a matrix
void OneDSparse::write(ostream &out) {
	if (size_set)
		out << "SIZE " << nrows << " " << ncolumns << endl;
	for (Miter m=matrix.begin(); m!=matrix.end(); m++)
		if (size_set) {
			div_t split=div((int)m->first,(int)ncolumns);
			out << split.quot << " " << split.rem << " " << m->second << endl;
		} else
			out << m->first << " " << m->second << endl;
	out << "END\n";
}

// Read in a matrix
void OneDSparse::read(istream &in) {
	string token;
	unsigned column=0,row=0;
	mtype value;
	unsigned count=0;
	
  in >> token;
	while (true) {
		if (token=="SIZE") {
			size_set=true;
			in >> nrows >> ncolumns >> token;
		} else if (token=="SYMMETRIC") {
			int value;
			in >> value >> token;
			if (value==1)
				symmetric=true;
			else if (value==0)
				symmetric=false;
			else {
				cerr << "Improperly formatted sparse matrix!";
				exit(1);
			}
		} else if (token=="SPARSE") {
			int value;
			in >> value >> token;
			if (value==1)
				sparse=true;
			else if (value==0)
				sparse=false;
			else {
				cerr << "Improperly formatted sparse matrix!";
				exit(1);
			}
		} else break;
	}
			
	if (!sparse) {
		if (symmetric==false)
			fmatrix=new mtype[nrows*ncolumns];
		else
			fmatrix=new mtype[nrows*(nrows+1)/2];
	}
	
	while (true) {
		if (in.eof()) {
			cerr << "Improperly formatted sparse matrix!";
			return;
		}
		if (token=="END")
			return;
		if (sparse) {
			row=atoi(token.c_str());
			if (size_set) {
				in >> column;
				#ifdef DEBUG
				assert (column<ncolumns && row<nrows);
				#endif
				in >> value;
				set(row,column,value);
			} else {
				in >> value;
				set(row,value);
			}
		} else {
			value=atof(token.c_str());
			set(row,column,value);
			column++;
			if (column==ncolumns) {
				row++;
				if (symmetric)
					column=row;
				else
					column=0;
			}
		}	
		count++;
		in >> token;
	}
}
