/***************************************************************************
                                 oneDsparse.h
                             -------------------
                               W. Michael Brown

	1 Dimensional Sparse Matrix
	Insert/Access in log(N)
	
	- Added ability to store as a full matrix with constant time set/access

 __________________________________________________________________________
    This file is part of the Math Library
 __________________________________________________________________________

    begin                : Mon May 24 2003
    copyright            : (C) 2004 by W. Michael Brown
    email                : wmbrown@sandia.gov
 ***************************************************************************/

// Note: This code has been de-templated from the previous version.
// Shawn Martin, 12/13/2012.

#ifndef ONEDSPARSE_H
#define ONEDSPARSE_H
  
#include <map>
#include <string>
#include <iostream>
#include <fstream>
using namespace std;

typedef float mtype;  // Specify the value held by the matrix

/// 1 Dimensional Sparse Matrix
/** 2-D access can be achieved with size() to set the size of the matrix
  * Insert and Retrieve occur in log(N) time */

class OneDSparse {
 public:
  /// Initialize matrix and set the zero value for 'empty cells'
	OneDSparse(mtype &zero);
  /// Initialize matrix with a 2-D size and set zero value for 'empty cells'
	OneDSparse(bool symmetry, bool sparse, unsigned rows, unsigned columns, 
						 mtype &zero);

  /// Clear the matrix and (optionally) the matrix size
  void clear();
  /// Test if the matrix is empty
  bool empty();

	/// Set the size for the matrix
	/** \note This should be performed before entry of data! **/
  void size(unsigned rows, unsigned columns);
  /// Get the number of columns in the matrix
  unsigned columns();
  /// Get the number of rows in the matrix
  unsigned rows();

  /// 1-D access for a cell
	mtype& operator[] (const unsigned i);
	/// 2-D access for a cell
	mtype& operator() (const unsigned row, const unsigned col);

	/// 1-D set for the value of a cell
	/** \note To set a cell to zero, use zero() */
	void set(const unsigned i, const mtype &value);
	/// 2-D set for the value of a cell
	/** \note To set a cell to zero, use zero() */
	void set(const unsigned row, const unsigned col, const mtype &value);
  /// Set the value of a cell to 'zero' using 1D access
  void zero(const unsigned i);
  /// Set the value of a cell to 'zero' using 2D access
  void zero(const unsigned row, const unsigned col);

	/// Write out a matrix
	/** \note operator << must be defined for the container type
	  *
	  * Output format for a 1D accessed matrix:
	  * \verbatim i1 value
	  * i2 value
	  * ...
	  * END \endverbatim
	  * Where i1 is the index for the first non-zero element
	  *
	  * For a 2D accessed matrix:
	  * \verbatim SIZE rows columns
		* row1 column1 value1
		* row2 column2 value2
		* ...
		* END \endverbatim
		*/
	void write(ostream &out);
	/// Read in a matrix
	/** \note The matrix is not emptied
	  * operator >> must be defined for the container type
	  *
	  * For a description of the input format, see operator<<*/
	void read(istream &in);

 private:
  OneDSparse();       // Declare away
	bool sparse;        // True if the matrix is sparse, false otherwise
	bool symmetric;      // True if the matrix is symetric, false otherwise
	
	// Sparse Matrix	
  map<unsigned,mtype> matrix;
  typedef map<unsigned,mtype>::iterator Miter;
  mtype zerovalue; // Value for a zero for the sparse matrix
	
	// Full Matrix
	mtype* fmatrix;

	bool size_set; // Whether or not the size has been set for 2D access
	unsigned ncolumns,nrows; // 2D size
};

#endif
