/************************************************************************/
/*                                                                      */
/*   kernel.h                                                           */
/*                                                                      */
/*   User defined kernel function. Feel free to plug in your own.       */
/*                                                                      */
/*   Copyright: Thorsten Joachims                                       */
/*   Date: 16.12.97                                                     */
/*                                                                      */
/************************************************************************/

/* KERNEL_PARM is defined in svm_common.h The field 'custom' is reserved for */
/* parameters of the user defined kernel. You can also access and use */
/* the parameters of the other kernels. Just replace the line 
             return((double)(1.0)); 
   with your own kernel. */

  /* Example: The following computes the polynomial kernel. sprod_ss
              computes the inner product between two sparse vectors. 

      return((CFLOAT)pow(kernel_parm->coef_lin*sprod_ss(a->words,b->words)
             +kernel_parm->coef_const,(double)kernel_parm->poly_degree)); 
  */

/* note: after extensive trial and error I have discovered that this program can take in ->wnums  */
/* which are not zero.  whenever this occurs the returned answer is supposed to be 0.  In order   */
/* to conform to this we return 0 as well.                       						  */

double custom_kernel(KERNEL_PARM *kernel_parm, DOC *a, DOC *b) 
     /* plug in you favorite kernel */                          
{
  /* allow access to globabl kernel matrix */
  extern struct SMatrix* sparse_matrix; /* WMB - Use sparse instead */
  extern int Y2H_shawn[Y2H_SHAWN_SIZE][2];

  int ind_i, ind_j, swap;		/* feature vectors are actually indices into kernel matrix */

  CFLOAT xdoty, xdotx, ydoty;

  CFLOAT kernel_answer;
  kernel_answer = 0;

  if ((a->words)->wnum && (b->words)->wnum) { /* kernel answer is not zero */
	  ind_i = (a->words)->weight;
	  ind_j = (b->words)->weight;
	  if (ind_i > ind_j) {
		  ind_i = (b->words)->weight;
		  ind_j = (a->words)->weight;
	  }

        if ( strcmp(kernel_parm->custom,"asym") == 0)
	  {
	  /* asymetric kernel */
	  kernel_answer = (sparse_get(sparse_matrix, Y2H_shawn[ind_i][0], Y2H_shawn[ind_j][0]) *
		 sparse_get(sparse_matrix, Y2H_shawn[ind_i][1] ,Y2H_shawn[ind_j][1]));
        }

        if ( strcmp(kernel_parm->custom,"sym") == 0 )
        {
	  /* symmetric kernel */
 	  kernel_answer = 2.0*
		(sparse_get(sparse_matrix, Y2H_shawn[ind_i][0] ,Y2H_shawn[ind_j][0]) *
		 sparse_get(sparse_matrix, Y2H_shawn[ind_i][1] ,Y2H_shawn[ind_j][1]) + 
		 sparse_get(sparse_matrix, Y2H_shawn[ind_i][1] ,Y2H_shawn[ind_j][0]) *
		 sparse_get(sparse_matrix, Y2H_shawn[ind_i][0] ,Y2H_shawn[ind_j][1]));
	  }

        if (strcmp(kernel_parm->custom,"rbf") == 0 )
	  {
	  /* rbf modification */
	  xdoty = 2.0*
		(sparse_get(sparse_matrix, Y2H_shawn[ind_i][0] ,Y2H_shawn[ind_j][0]) *
		 sparse_get(sparse_matrix, Y2H_shawn[ind_i][1] ,Y2H_shawn[ind_j][1]) + 
		 sparse_get(sparse_matrix, Y2H_shawn[ind_i][1] ,Y2H_shawn[ind_j][0]) *
		 sparse_get(sparse_matrix, Y2H_shawn[ind_i][0] ,Y2H_shawn[ind_j][1]));

 	  xdotx = 2.0*
		(sparse_get(sparse_matrix, Y2H_shawn[ind_i][0] ,Y2H_shawn[ind_i][0]) *
		 sparse_get(sparse_matrix, Y2H_shawn[ind_i][1] ,Y2H_shawn[ind_i][1]) + 
		 sparse_get(sparse_matrix, Y2H_shawn[ind_i][1] ,Y2H_shawn[ind_i][0]) *
		 sparse_get(sparse_matrix, Y2H_shawn[ind_i][0] ,Y2H_shawn[ind_i][1]));

	  ydoty = 2.0*
		(sparse_get(sparse_matrix, Y2H_shawn[ind_j][0] ,Y2H_shawn[ind_j][0]) *
		 sparse_get(sparse_matrix, Y2H_shawn[ind_j][1] ,Y2H_shawn[ind_j][1]) + 
		 sparse_get(sparse_matrix, Y2H_shawn[ind_j][1] ,Y2H_shawn[ind_j][0]) *
		 sparse_get(sparse_matrix, Y2H_shawn[ind_j][0] ,Y2H_shawn[ind_j][1]));

	  kernel_answer = (CFLOAT)exp(-kernel_parm->rbf_gamma*(xdotx-2*xdoty+ydoty));
	  }
  }
  return((CFLOAT)kernel_answer);
}
