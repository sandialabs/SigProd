/***************************************************************************
                              sparsewrapper.cpp
                             -------------------
                               W. Michael Brown

	Wrapper functions for calling the sparse matrix class from C
															 
 __________________________________________________________________________
 __________________________________________________________________________

    begin                : Mon May 24 2003
    copyright            : (C) 2004 by W. Michael Brown
    email                : wmbrown@sandia.gov
 ***************************************************************************/

#include "oneDsparse.h"
#include <cstdlib>

extern "C" {
    
	// Create a Matrix and return a pointer two it
	OneDSparse * create_sparse() {
		mtype zero=0;
		return new OneDSparse(zero);
	}
	
	// Read a matrix from a specified file name
	void read_sparse(OneDSparse *matrix, char *filename) {
		ifstream in;
		in.open(filename);
		if (!in) {
			cerr << "Could not open " << filename << " for kernel matrix!\n";
			exit(1);
		}
		matrix->read(in);
	}
	
	// Access a matrix element (NOTE: Changed to 1-based indexing for Shawn)
	mtype sparse_get(OneDSparse *matrix, unsigned i, unsigned j) {
		return (*matrix)(i,j);
	}
	
	// Set a matrix element (NOTE: Changed to 1-based indexing for Shawn)
	void sparse_set(OneDSparse *matrix, unsigned i, unsigned j, mtype value) {
		matrix->set(i,j,value);
	}
	
	// Delete the Matrix
	void delete_sparse(OneDSparse *matrix) {
		delete matrix;
	}
	
	// Number of rows
	unsigned sparse_rows(OneDSparse *matrix) {
  	return matrix->rows();
  }
  
  // Number of columns
	unsigned sparse_columns(OneDSparse *matrix) {
  	return matrix->columns();
  }

}
